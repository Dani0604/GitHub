package TankGame;

public class PowerUp {

}
