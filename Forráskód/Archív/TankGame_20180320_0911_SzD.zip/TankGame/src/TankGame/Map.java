package TankGame;

public class Map {

}
